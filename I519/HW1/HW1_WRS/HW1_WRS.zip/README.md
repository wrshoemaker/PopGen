# README

## Running TypeFASTASeq.py

To run the program, cd to the directory containing TypeFASTASeq.py and run the following command:

	 YourAccount$ python TypeFASTASeq.py YourSequence.fa 
	 
the third term above your fasta file. If it is not in the directory of the script, please provide a file path with your file name.