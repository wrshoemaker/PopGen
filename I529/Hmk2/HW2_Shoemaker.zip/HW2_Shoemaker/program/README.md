# README

### ECgnfinder_mc

**-i:** Training FASTA file

**-j:** Testing FASTA file

**-o:** Output txt file of log-likelihood ratios

##### command line example

python ECgnfinder_mc.py -i test_ecoli.fasta -j noncoding_test_misc.fasta -o non_coding_test_out.txt