DiNuc.py

input FASTA file as follows 
	
	python DiNuc.py -i genome.fa